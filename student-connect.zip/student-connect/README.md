# Student Connect

A mobile-first React/Vite frontend connected to the supplied Supabase project.

## Run
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown by Vite.

## Supabase
The app uses the existing tables and buckets. It does not create or drop tables.

Before production, verify:
- RLS policies on all 12 tables
- Storage policies for all 4 buckets
- `chat-images` remains private
- Supabase Auth Email Confirmation is disabled if password login should work immediately

## Admin
The existing admin UUID is used for database lookup:
`8e85eff1-cdfc-43eb-9a5c-89348b2dc365`

The frontend checks `admin_users` after authentication. Database RLS must independently enforce admin privileges.

## Notes
The current UI is a working foundation. Education/Institution discovery is prepared around the existing schema but should be refined against the exact live column definitions before production.
