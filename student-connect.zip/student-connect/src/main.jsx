import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import {
  Home, MessageCircle, UserRound, Plus, Search, LogOut, Camera, Send,
  Heart, MessageSquare, Users, ShieldCheck, GraduationCap, X, Check,
  UserPlus, Menu, ChevronLeft
} from 'lucide-react';
import './styles.css';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://hiitiilabdqmrohanopn.supabase.co';
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_gu8AkmNows-XOtnLFBZ7EA_Z1VUD0il';
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
const ADMIN_ID = '8e85eff1-cdfc-43eb-9a5c-89348b2dc365';

const avatar = (url, name='Student') => url || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=2563eb&color=fff`;
const fmt = (d) => d ? new Date(d).toLocaleString('bn-BD', {dateStyle:'medium', timeStyle:'short'}) : '';

function App(){
  const [session,setSession]=useState(null), [profile,setProfile]=useState(null);
  const [screen,setScreen]=useState('home'), [auth,setAuth]=useState('login');
  const [loading,setLoading]=useState(true), [notice,setNotice]=useState('');
  const [isAdmin,setIsAdmin]=useState(false);

  async function loadUser(s){
    if(!s?.user){ setSession(null); setProfile(null); setIsAdmin(false); setLoading(false); return; }
    setSession(s);
    let {data:p}=await supabase.from('profiles').select('*').eq('id',s.user.id).maybeSingle();
    if(!p){
      const {data:np}=await supabase.from('profiles').insert({id:s.user.id,full_name:s.user.user_metadata?.full_name || s.user.email?.split('@')[0] || 'Student'}).select().single();
      p=np;
    }
    setProfile(p);
    const {data:a}=await supabase.from('admin_users').select('role,is_active').eq('profile_id',s.user.id).maybeSingle();
    setIsAdmin(!!a?.is_active);
    setLoading(false);
  }

  useEffect(()=>{
    supabase.auth.getSession().then(({data})=>loadUser(data.session));
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>loadUser(s));
    return ()=>subscription.unsubscribe();
  },[]);

  if(loading) return <Splash/>;
  if(!session) return <Auth auth={auth} setAuth={setAuth} notice={notice} setNotice={setNotice}/>;
  if(isAdmin && screen==='admin') return <Admin profile={profile} goHome={()=>setScreen('home')} />;
  return <Shell screen={screen} setScreen={setScreen} profile={profile} isAdmin={isAdmin} setNotice={setNotice} onAdmin={()=>setScreen('admin')}/>;
}

function Splash(){return <div className="splash"><div className="logoMark"><GraduationCap/></div><h1>Student Connect</h1><p>পুরোনো পরিচিতদের আবার খুঁজে নিন</p></div>}

function Auth({auth,setAuth,notice,setNotice}){
  const [name,setName]=useState(''),[email,setEmail]=useState(''),[institution,setInstitution]=useState(''),[password,setPassword]=useState(''),[confirm,setConfirm]=useState(''),[busy,setBusy]=useState(false);
  async function submit(e){
    e.preventDefault(); setNotice('');
    if(auth==='register' && password!==confirm) return setNotice('পাসওয়ার্ড মিলছে না।');
    if(!email||!password||(auth==='register'&&!name)) return setNotice('প্রয়োজনীয় তথ্য পূরণ করুন।');
    setBusy(true);
    if(auth==='register'){
      const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name,institution_name:institution}}});
      if(error) setNotice(error.message);
      else if(data.session){
        await supabase.from('profiles').upsert({id:data.user.id,full_name:name});
        setNotice('অ্যাকাউন্ট তৈরি হয়েছে।');
      } else setNotice('অ্যাকাউন্ট তৈরি হয়েছে। Supabase-এ Email Confirmation চালু থাকলে ইমেইল নিশ্চিত করতে হবে।');
    } else {
      const {error}=await supabase.auth.signInWithPassword({email,password});
      if(error) setNotice(error.message);
    }
    setBusy(false);
  }
  async function forgot(){
    if(!email) return setNotice('আগে Email দিন।');
    const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:location.origin});
    setNotice(error ? error.message : 'Password reset link পাঠানো হয়েছে।');
  }
  return <div className="authPage">
    <div className="authCard">
      <div className="brand"><div className="logoMark small"><GraduationCap/></div><div><b>Student Connect</b><span>Reconnect • Learn • Connect</span></div></div>
      <h2>{auth==='login'?'স্বাগতম 👋':'নতুন অ্যাকাউন্ট তৈরি করুন'}</h2>
      <p className="muted">{auth==='login'?'আপনার পুরোনো পরিচিতদের খুঁজে নিন।':'শিক্ষার্থীদের কমিউনিটিতে যোগ দিন।'}</p>
      {notice&&<div className="notice">{notice}</div>}
      <form onSubmit={submit}>
        {auth==='register'&&<><label>পূর্ণ নাম<input value={name} onChange={e=>setName(e.target.value)} placeholder="আপনার নাম"/></label><label>প্রতিষ্ঠানের নাম<input value={institution} onChange={e=>setInstitution(e.target.value)} placeholder="মাদ্রাসা / স্কুল / কলেজ"/></label></>}
        <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@example.com"/></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••"/></label>
        {auth==='register'&&<label>Confirm Password<input type="password" value={confirm} onChange={e=>setConfirm(e.target.value)} placeholder="••••••••"/></label>}
        <button className="primary full" disabled={busy}>{busy?'অপেক্ষা করুন…':auth==='login'?'Login':'Create Account'}</button>
      </form>
      {auth==='login'&&<button className="linkBtn" onClick={forgot}>Password ভুলে গেছেন?</button>}
      <div className="switch">{auth==='login'?<>অ্যাকাউন্ট নেই? <button onClick={()=>setAuth('register')}>Registration</button></>:<>আগে থেকেই অ্যাকাউন্ট আছে? <button onClick={()=>setAuth('login')}>Login</button></>}</div>
    </div>
  </div>
}

function Shell({screen,setScreen,profile,isAdmin,setNotice,onAdmin}){
  const [search,setSearch]=useState('');
  const [selected,setSelected]=useState(null);
  const [chatUser,setChatUser]=useState(null);
  const [showCreate,setShowCreate]=useState(false);
  const [menu,setMenu]=useState(false);
  async function logout(){await supabase.auth.signOut();}
  return <div className="app">
    <header className="topbar"><div className="brand"><div className="logoMark small"><GraduationCap/></div><b>Student Connect</b></div>
      <div className="topActions"><div className="searchMini"><Search size={17}/><input placeholder="শিক্ষার্থী খুঁজুন" value={search} onChange={e=>setSearch(e.target.value)}/></div><button className="iconBtn" onClick={()=>setMenu(!menu)}><Menu/></button></div>
      {menu&&<div className="menuPop"><button onClick={()=>setScreen('profile')}><UserRound/> Profile</button>{isAdmin&&<button onClick={onAdmin}><ShieldCheck/> Admin</button>}<button onClick={logout}><LogOut/> Logout</button></div>}
    </header>
    <main className="main">
      {screen==='home'&&<HomePage profile={profile} search={search} openProfile={setSelected} openChat={setChatUser} create={()=>setShowCreate(true)}/>}
      {screen==='chat'&&<ChatPage me={profile} initialUser={chatUser} />}
      {screen==='profile'&&<ProfilePage profile={profile} onUpdated={()=>{}} openProfile={setSelected}/>}
    </main>
    <nav className="bottomNav"><button className={screen==='home'?'active':''} onClick={()=>setScreen('home')}><Home/><span>Home</span></button><button className={screen==='chat'?'active':''} onClick={()=>setScreen('chat')}><MessageCircle/><span>Chat</span></button><button className={screen==='profile'?'active':''} onClick={()=>setScreen('profile')}><UserRound/><span>Profile</span></button></nav>
    {screen==='home'&&<button className="fab" onClick={()=>setShowCreate(true)}><Plus/></button>}
    {showCreate&&<CreatePost close={()=>setShowCreate(false)} profile={profile}/>}
    {selected&&<ProfileModal id={selected} me={profile} close={()=>setSelected(null)} message={()=>{setChatUser(selected);setSelected(null);setScreen('chat')}}/>}
  </div>
}

function HomePage({profile,search,openProfile,openChat,create}){
  const [students,setStudents]=useState([]),[posts,setPosts]=useState([]),[loading,setLoading]=useState(true);
  useEffect(()=>{load()},[search,profile?.id]);
  async function load(){
    setLoading(true);
    let q=supabase.from('profiles').select('*').neq('id',profile.id).eq('status','active').order('created_at',{ascending:false}).limit(30);
    if(search) q=q.or(`full_name.ilike.%${search}%,username.ilike.%${search}%`);
    const {data:st}=await q; setStudents(st||[]);
    const {data:ps}=await supabase.from('posts').select('*,profiles(id,full_name,profile_image)').order('created_at',{ascending:false}).limit(30);
    setPosts(ps||[]); setLoading(false);
  }
  return <div className="feed">
    <section className="welcomeCard"><div><span className="eyebrow">WELCOME BACK</span><h2>আবার পরিচিত হোন, আবার যুক্ত হোন।</h2><p>আপনার সহপাঠী ও পুরোনো পরিচিতদের খুঁজে বের করুন।</p></div><button className="primary" onClick={create}><Plus size={18}/> Post করুন</button></section>
    <section><div className="sectionTitle"><div><h3>আপনার পরিচিতদের খুঁজুন</h3><p>একই প্রতিষ্ঠান ও ব্যাচের মানুষকে আগে দেখানো হবে।</p></div></div>
      <div className="studentGrid">{loading?[1,2,3].map(i=><div className="skeleton" key={i}/>):students.map(s=><StudentCard key={s.id} s={s} openProfile={openProfile} openChat={openChat}/>)}</div>
    </section>
    <section><div className="sectionTitle"><div><h3>সবার পোস্ট</h3><p>কমিউনিটির নতুন কথাগুলো দেখুন।</p></div></div>
      <div className="posts">{posts.map(p=><PostCard key={p.id} p={p} me={profile} />)}</div>
      {!posts.length&&<div className="empty">এখনও কোনো পোস্ট নেই। প্রথম পোস্টটি আপনি করুন।</div>}
    </section>
  </div>
}

function StudentCard({s,openProfile,openChat}){
  return <div className="studentCard"><img src={avatar(s.profile_image,s.full_name)} /><div className="studentInfo"><h4>{s.full_name||'Student'}</h4><p>{s.username?`@${s.username}`:'Student Connect member'}</p><div className="cardActions"><button className="outline" onClick={()=>openProfile(s.id)}>Profile</button><button className="primary smallBtn" onClick={()=>openChat(s.id)}><MessageCircle size={15}/> Message</button></div></div></div>
}

function PostCard({p,me}){
  const [liked,setLiked]=useState(false),[count,setCount]=useState(0);
  useEffect(()=>{(async()=>{const {data}=await supabase.from('post_likes').select('id').eq('post_id',p.id).eq('profile_id',me.id).maybeSingle();setLiked(!!data);const {count:c}=await supabase.from('post_likes').select('*',{count:'exact',head:true}).eq('post_id',p.id);setCount(c||0)})()},[p.id]);
  async function like(){if(liked){await supabase.from('post_likes').delete().eq('post_id',p.id).eq('profile_id',me.id);setLiked(false);setCount(x=>x-1)}else{await supabase.from('post_likes').insert({post_id:p.id,profile_id:me.id});setLiked(true);setCount(x=>x+1)}}
  return <article className="postCard"><div className="postHead"><img src={avatar(p.profiles?.profile_image,p.profiles?.full_name)}/><div><b>{p.profiles?.full_name||'Student'}</b><span>{fmt(p.created_at)}</span></div></div><p className="postText">{p.content}</p>{p.post_images?.length>0&&<div className="postImages">{p.post_images.map(i=><img src={i.image_url} key={i.id}/>)}</div>}<div className="postBar"><button onClick={like} className={liked?'liked':''}><Heart size={18} fill={liked?'currentColor':'none'}/> {count}</button><button><MessageSquare size={18}/> Comment</button></div></article>
}

function CreatePost({close,profile}){
  const [text,setText]=useState(''),[file,setFile]=useState(null),[preview,setPreview]=useState(''),[busy,setBusy]=useState(false),[msg,setMsg]=useState('');
  function choose(e){const f=e.target.files?.[0];if(f){setFile(f);setPreview(URL.createObjectURL(f))}}
  async function submit(e){e.preventDefault();if(!text.trim()&&!file)return;setBusy(true);
    const {data:p,error}=await supabase.from('posts').insert({profile_id:profile.id,content:text.trim(),post_type:file?'image':'text'}).select().single();
    if(error){setMsg(error.message);setBusy(false);return}
    if(file){const ext=file.name.split('.').pop();const path=`${profile.id}/${crypto.randomUUID()}.${ext}`;const up=await supabase.storage.from('post-images').upload(path,file);if(!up.error){const {data:{publicUrl}}=supabase.storage.from('post-images').getPublicUrl(path);await supabase.from('post_images').insert({post_id:p.id,image_url:publicUrl,sort_order:0})}}
    setBusy(false);close();location.reload();
  }
  return <div className="modalBack"><div className="modal"><div className="modalHead"><h3>নতুন পোস্ট</h3><button onClick={close}><X/></button></div><form onSubmit={submit}><textarea value={text} onChange={e=>setText(e.target.value)} placeholder="আপনার কথা লিখুন…"/>{preview&&<img className="preview" src={preview}/>}<div className="uploadRow"><label className="outline upload"><Camera size={18}/> Gallery<input type="file" accept="image/*" onChange={choose}/></label><button className="primary" disabled={busy}>{busy?'Posting…':'Post করুন'}</button></div>{msg&&<p className="error">{msg}</p>}</form></div></div>
}

function ProfilePage({profile}){
  const [edit,setEdit]=useState(false),[name,setName]=useState(profile?.full_name||''),[bio,setBio]=useState(profile?.bio||''),[city,setCity]=useState(profile?.current_city||''),[busy,setBusy]=useState(false);
  async function save(e){e.preventDefault();setBusy(true);await supabase.from('profiles').update({full_name:name,bio,current_city:city,updated_at:new Date().toISOString()}).eq('id',profile.id);setBusy(false);setEdit(false);location.reload()}
  async function image(e,type){const f=e.target.files?.[0];if(!f)return;const bucket=type==='profile'?'profile-images':'cover-images';const path=`${profile.id}/${crypto.randomUUID()}.${f.name.split('.').pop()}`;const up=await supabase.storage.from(bucket).upload(path,f,{upsert:true});if(up.error)return alert(up.error.message);const {data:{publicUrl}}=supabase.storage.from(bucket).getPublicUrl(path);await supabase.from('profiles').update(type==='profile'?{profile_image:publicUrl}:{cover_image:publicUrl}).eq('id',profile.id);location.reload()}
  return <div className="profilePage"><div className="cover" style={{backgroundImage:`url(${profile.cover_image||'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1200&q=80'})`}}><label className="coverCam"><Camera/><input type="file" accept="image/*" onChange={e=>image(e,'cover')}/></label></div><div className="profileBody"><div className="avatarWrap"><img src={avatar(profile.profile_image,profile.full_name)}/><label className="avatarCam"><Camera/><input type="file" accept="image/*" onChange={e=>image(e,'profile')}/></label></div>{!edit?<><div className="profileTop"><div><h1>{profile.full_name}</h1><p>{profile.username?`@${profile.username}`:''}</p></div><button className="outline" onClick={()=>setEdit(true)}>Edit Profile</button></div><div className="profileGrid"><Info title="About" value={profile.bio}/><Info title="Current City" value={profile.current_city}/><Info title="Profession" value={profile.profession}/><Info title="Skills" value={profile.skills}/><Info title="Interests" value={profile.interests}/></div></>:<form className="editForm" onSubmit={save}><label>নাম<input value={name} onChange={e=>setName(e.target.value)}/></label><label>About<textarea value={bio} onChange={e=>setBio(e.target.value)}/></label><label>Current City<input value={city} onChange={e=>setCity(e.target.value)}/></label><div><button type="button" className="outline" onClick={()=>setEdit(false)}>Cancel</button><button className="primary" disabled={busy}>{busy?'Saving…':'Save'}</button></div></form>}</div></div>
}
function Info({title,value}){return <div className="infoBox"><span>{title}</span><b>{value||'তথ্য যোগ করা হয়নি'}</b></div>}

function ProfileModal({id,me,close,message}){
  const [p,setP]=useState(null);useEffect(()=>{supabase.from('profiles').select('*').eq('id',id).single().then(({data})=>setP(data))},[id]);
  if(!p)return <div className="modalBack"><div className="modal"><p>লোড হচ্ছে…</p></div></div>;
  return <div className="modalBack"><div className="modal profileModal"><button className="closeX" onClick={close}><X/></button><img className="bigAvatar" src={avatar(p.profile_image,p.full_name)}/><h2>{p.full_name}</h2><p>{p.bio||'Student Connect member'}</p><div className="modalInfo"><Info title="City" value={p.current_city}/><Info title="Profession" value={p.profession}/></div><button className="primary full" onClick={message}><MessageCircle/> Message</button></div></div>
}

function ChatPage({me,initialUser}){
  const [users,setUsers]=useState([]),[selected,setSelected]=useState(null),[messages,setMessages]=useState([]),[text,setText]=useState(''),[conversation,setConversation]=useState(null),[busy,setBusy]=useState(false);
  useEffect(()=>{loadUsers()},[]);
  useEffect(()=>{if(initialUser){supabase.from('profiles').select('*').eq('id',initialUser).single().then(({data})=>{setSelected(data);openConversation(data)})}},[initialUser]);
  async function loadUsers(){const {data}=await supabase.from('profiles').select('*').neq('id',me.id).eq('status','active').limit(50);setUsers(data||[])}
  async function openConversation(user){
    setSelected(user);
    const {data:mine}=await supabase.from('conversation_members').select('conversation_id').eq('profile_id',me.id);
    const ids=(mine||[]).map(x=>x.conversation_id);
    let found=null;
    if(ids.length){const {data:other}=await supabase.from('conversation_members').select('conversation_id').eq('profile_id',user.id).in('conversation_id',ids).maybeSingle();found=other?.conversation_id}
    if(!found){const {data:c}=await supabase.from('conversations').insert({}).select().single();found=c.id;await supabase.from('conversation_members').insert([{conversation_id:found,profile_id:me.id},{conversation_id:found,profile_id:user.id}])}
    setConversation(found);const {data:ms}=await supabase.from('messages').select('*').eq('conversation_id',found).order('created_at');setMessages(ms||[]);
  }
  useEffect(()=>{if(!conversation)return;const channel=supabase.channel('chat-'+conversation).on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:`conversation_id=eq.${conversation}`},payload=>setMessages(m=>[...m,payload.new])).subscribe();return()=>supabase.removeChannel(channel)},[conversation]);
  async function send(e){e.preventDefault();if(!text.trim()||!conversation||busy)return;setBusy(true);await supabase.from('messages').insert({conversation_id:conversation,sender_id:me.id,message_type:'text',content:text.trim()});setText('');setBusy(false)}
  return <div className="chatLayout"><aside className="chatList"><div className="chatTitle"><h2>Chat</h2><span>{users.length} জন</span></div>{users.map(u=><button className={`chatUser ${selected?.id===u.id?'selected':''}`} key={u.id} onClick={()=>openConversation(u)}><img src={avatar(u.profile_image,u.full_name)}/><div><b>{u.full_name}</b><span>Message করুন</span></div></button>)}</aside><section className="chatWindow">{selected?<><div className="chatHeader"><button className="mobileBack" onClick={()=>setSelected(null)}><ChevronLeft/></button><img src={avatar(selected.profile_image,selected.full_name)}/><div><b>{selected.full_name}</b><span>Student Connect</span></div></div><div className="messages">{messages.map(m=><div className={`bubble ${m.sender_id===me.id?'mine':''}`} key={m.id}><p>{m.content}</p><small>{fmt(m.created_at)}</small></div>)}</div><form className="composer" onSubmit={send}><input value={text} onChange={e=>setText(e.target.value)} placeholder="Message লিখুন…"/><button className="primary" disabled={busy}><Send/></button></form></>:<div className="chatEmpty"><MessageCircle size={48}/><h3>একটি Chat নির্বাচন করুন</h3><p>যেকোনো শিক্ষার্থীকে Message করে পরিচিত হতে শুরু করুন।</p></div>}</section></div>
}

function Admin({profile,goHome}){
  const [tab,setTab]=useState('dashboard'),[students,setStudents]=useState([]),[posts,setPosts]=useState([]),[institutions,setInstitutions]=useState([]),[stats,setStats]=useState({});
  useEffect(()=>{load()},[tab]);
  async function count(t){const {count}=await supabase.from(t).select('*',{count:'exact',head:true});return count||0}
  async function load(){const [s,p,i,c]=await Promise.all([count('profiles'),count('posts'),count('institutions'),count('connections')]);setStats({students:s,posts:p,institutions:i,connections:c});if(tab==='students'){const {data}=await supabase.from('profiles').select('*').order('created_at',{ascending:false});setStudents(data||[])}if(tab==='posts'){const {data}=await supabase.from('posts').select('*,profiles(full_name)').order('created_at',{ascending:false});setPosts(data||[])}if(tab==='institutions'){const {data}=await supabase.from('institutions').select('*').order('name');setInstitutions(data||[])}}
  async function status(id,value){await supabase.from('profiles').update({status:value}).eq('id',id);load()}
  async function delPost(id){await supabase.from('posts').delete().eq('id',id);load()}
  return <div className="admin"><aside className="adminSide"><div className="brand"><div className="logoMark small"><ShieldCheck/></div><b>Admin Panel</b></div><button className={tab==='dashboard'?'on':''} onClick={()=>setTab('dashboard')}>Dashboard</button><button className={tab==='students'?'on':''} onClick={()=>setTab('students')}>Students</button><button className={tab==='posts'?'on':''} onClick={()=>setTab('posts')}>Posts</button><button className={tab==='institutions'?'on':''} onClick={()=>setTab('institutions')}>Institutions</button><button onClick={goHome}>← Website</button></aside><main className="adminMain"><div className="adminTop"><div><span className="eyebrow">SUPER ADMIN</span><h1>স্বাগতম, {profile.full_name}</h1></div><button className="outline" onClick={goHome}>Home</button></div>{tab==='dashboard'&&<div className="statGrid"><Stat icon={<Users/>} title="Students" value={stats.students}/><Stat icon={<MessageSquare/>} title="Posts" value={stats.posts}/><Stat icon={<GraduationCap/>} title="Institutions" value={stats.institutions}/><Stat icon={<UserPlus/>} title="Connections" value={stats.connections}/></div>}{tab==='students'&&<Table title="Students"><table><thead><tr><th>Name</th><th>Status</th><th>City</th><th>Action</th></tr></thead><tbody>{students.map(s=><tr key={s.id}><td><div className="tableUser"><img src={avatar(s.profile_image,s.full_name)}/>{s.full_name}</div></td><td><span className={`status ${s.status||'active'}`}>{s.status||'active'}</span></td><td>{s.current_city||'—'}</td><td><select value={s.status||'active'} onChange={e=>status(s.id,e.target.value)}><option value="active">Active</option><option value="suspended">Suspended</option><option value="disabled">Disabled</option></select></td></tr>)}</tbody></table></Table>}{tab==='posts'&&<Table title="Posts"><table><thead><tr><th>Author</th><th>Content</th><th>Time</th><th>Action</th></tr></thead><tbody>{posts.map(p=><tr key={p.id}><td>{p.profiles?.full_name}</td><td>{(p.content||'').slice(0,80)}</td><td>{fmt(p.created_at)}</td><td><button className="dangerBtn" onClick={()=>delPost(p.id)}>Delete</button></td></tr>)}</tbody></table></Table>}{tab==='institutions'&&<Table title="Institutions"><table><thead><tr><th>Name</th><th>Type</th><th>Location</th></tr></thead><tbody>{institutions.map(i=><tr key={i.id}><td>{i.name}</td><td>{i.type}</td><td>{i.location||'—'}</td></tr>)}</tbody></table></Table>}</main></div>
}
function Stat({icon,title,value}){return <div className="stat"><div className="statIcon">{icon}</div><span>{title}</span><strong>{value}</strong></div>}
function Table({title,children}){return <section className="tableCard"><h2>{title}</h2>{children}</section>}

createRoot(document.getElementById('root')).render(<App/>);
